    </div>
<!-- Add your footer content here -->
    <script src="./assets/js/jquery.min.js"></script>
    <script src="./assets/js/popper.min.js"></script>
    <script src="./assets/js/moment.min.js"></script>
    <script src="./assets/js/bootstrap.min.js"></script>
    <script src="./assets/js/simplebar.min.js"></script>
    <script src='./assets/js/daterangepicker.js'></script>
    <script src='./assets/js/jquery.stickOnScroll.js'></script>
    <script src="./assets/js/tinycolor-min.js"></script>
    <script src="./assets/js/apps.js"></script>
</body>
</html>

