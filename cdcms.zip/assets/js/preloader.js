$(document).ready(function () {
    // Preloader
    $('.loader').fadeOut(1000);
    $('.loader-mask').delay(500).fadeOut('1000');
});