<?php

define('MAILER_HOST', 'smtp.gmail.com');
define('MAILER_EMAIL', '@gmail.com');
define('MAILER_PASS', '');

