<?php

define('MAILER_HOST', 'smtp.gmail.com');
define('MAILER_EMAIL', 'cdcms168@gmail.com');
define('MAILER_PASS', 'dppc bunb dsaw lacx');

