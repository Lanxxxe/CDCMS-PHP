  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>  
  <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
  <script src="../assets/js/jquery.min.js"></script>
  <script src="../assets/js/popper.min.js"></script>
  <script src="../assets/js/moment.min.js"></script>
  <script src="../assets/js/bootstrap.min.js"></script>
  <script src="../assets/js/simplebar.min.js"></script>
  <script src="../assets/js/daterangepicker.js"></script>
  <script src="../assets/js/jquery.stickOnScroll.js"></script>
  <script src="../assets/js/tinycolor-min.js"></script>
  <script src="../assets/js/d3.min.js"></script>
  <script src="../assets/js/topojson.min.js"></script>
  <script src="../assets/js/Chart.min.js"></script>
  <script src="../assets/js/gauge.min.js"></script>
  <script src="../assets/js/jquery.sparkline.min.js"></script>
  <script src="../assets/js/apexcharts.min.js"></script>
  <script src="../assets/js/apexcharts.custom.js"></script>
  <script src="../assets/js/jquery.mask.min.js"></script>
  <script src="../assets/js/select2.min.js"></script>
  <script src="../assets/js/jquery.steps.min.js"></script>
  <script src="../assets/js/jquery.validate.min.js"></script>
  <script src="../assets/js/jquery.timepicker.js"></script>
  <script src="../assets/js/dropzone.min.js"></script>
  <script src="../assets/js/uppy.min.js"></script>
  <script src="../assets/js/quill.min.js"></script>
  <script src="../assets/js/apps.js"></script>
  <script src="../assets/js/preloader.js"></script>
  <script src="../assets/js/jquery-3.6.0.min.js" crossorigin="anonymous"></script>
  <script src="../assets/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
  <script src="../assets/js/jquery.dataTables.min.js"></script>
  <script src="../assets/js/dataTables.bootstrap4.min.js"></script>
  <script src="../assets/js/notification.js"></script>

  </body>
</html>

